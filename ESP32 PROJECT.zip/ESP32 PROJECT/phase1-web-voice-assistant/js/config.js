/**
 * Central configuration: storage keys, defaults, supported languages,
 * and the command dictionary (English / Telugu / mixed trigger phrases).
 *
 * Every command also carries a `futureEndpoint`. It is NOT used in Phase 1 —
 * it is reserved so Phase 4/7 (ESP32 Wi-Fi integration) can reuse this same
 * command table without redesigning the architecture.
 */
const VA_CONFIG = (() => {
  const STORAGE_KEYS = {
    ASSISTANT_NAME: 'va_assistant_name',
    RECOGNITION_LANG: 'va_recognition_lang',
    VOICE_URI: 'va_voice_uri',
    SPEECH_RATE: 'va_speech_rate',
    HISTORY: 'va_command_history'
  };

  const DEFAULT_ASSISTANT_NAME = 'NOVA';
  const DEFAULT_RECOGNITION_LANG = 'en-IN';
  const MAX_HISTORY = 50;

  // Recognition languages the browser's speech engine can be pointed at.
  // See README note in ui.js settings panel re: why "mixed" isn't a real
  // browser recognition mode — it's handled via keyword matching instead.
  const LANGUAGE_OPTIONS = [
    { code: 'en-IN', label: 'English (India)' },
    { code: 'en-US', label: 'English (US)' },
    { code: 'te-IN', label: 'Telugu' }
  ];

  const COMMANDS = [
    {
      id: 'LIGHT_ON',
      description: 'Turn the light on',
      futureEndpoint: '/light/on',
      triggers: [
        'turn on the light', 'turn on light', 'light on', 'lights on',
        'switch on the light', 'switch the light on', 'put the light on',
        'లైట్ ఆన్ చెయ్యి', 'లైట్ వెయ్యి', 'దీపం వెయ్యి', 'దీపం ఆన్ చెయ్యి', 'లైట్ ఆన్',
        'light on cheyyi', 'light వెయ్యి', 'dipam veyyi', 'light on chey', 'light ఆన్ చెయ్యి', 'light veyyi'
      ]
    },
    {
      id: 'LIGHT_OFF',
      description: 'Turn the light off',
      futureEndpoint: '/light/off',
      triggers: [
        'turn off the light', 'turn off light', 'light off', 'lights off',
        'switch off the light', 'switch the light off', 'put the light off',
        'లైట్ ఆఫ్ చెయ్యి', 'లైట్ ఆపు', 'దీపం ఆపు', 'దీపం ఆఫ్ చెయ్యి', 'లైట్ ఆఫ్',
        'light off cheyyi', 'light apu', 'dipam apu', 'light off chey'
      ]
    },
    {
      id: 'FAN_ON',
      description: 'Turn the fan on',
      futureEndpoint: '/fan/on',
      triggers: [
        'turn on the fan', 'turn on fan', 'fan on', 'switch on the fan', 'start the fan',
        'ఫ్యాన్ ఆన్ చెయ్యి', 'ఫ్యాన్ వెయ్యి', 'ఫ్యాన్ ఆన్',
        'fan on cheyyi', 'fan veyyi', 'fan on chey'
      ]
    },
    {
      id: 'FAN_OFF',
      description: 'Turn the fan off',
      futureEndpoint: '/fan/off',
      triggers: [
        'turn off the fan', 'turn off fan', 'fan off', 'switch off the fan', 'stop the fan',
        'ఫ్యాన్ ఆఫ్ చెయ్యి', 'ఫ్యాన్ ఆపు', 'ఫ్యాన్ ఆఫ్',
        'fan off cheyyi', 'fan apu', 'fan off chey'
      ]
    },
    {
      id: 'MOTOR_ON',
      description: 'Turn the motor on',
      futureEndpoint: '/motor/on',
      triggers: [
        'turn on the motor', 'turn on motor', 'motor on', 'start the motor', 'switch on the motor',
        'మోటార్ ఆన్ చెయ్యి', 'మోటార్ వెయ్యి', 'మోటార్ ఆన్',
        'motor on cheyyi', 'motor veyyi', 'motor on chey'
      ]
    },
    {
      id: 'MOTOR_OFF',
      description: 'Turn the motor off',
      futureEndpoint: '/motor/off',
      triggers: [
        'turn off the motor', 'turn off motor', 'motor off', 'stop the motor', 'switch off the motor',
        'మోటార్ ఆఫ్ చెయ్యి', 'మోటార్ ఆపు', 'మోటార్ ఆఫ్',
        'motor off cheyyi', 'motor apu', 'motor off chey'
      ]
    },
    {
      id: 'GET_TEMPERATURE',
      description: 'Read the current (simulated) temperature',
      futureEndpoint: '/temperature',
      triggers: [
        'what is the temperature', 'get temperature', 'temperature', 'how hot is it', 'tell me the temperature',
        'ఉష్ణోగ్రత చెప్పు', 'టెంపరేచర్ చెప్పు', 'ఉష్ణోగ్రత ఎంత',
        'temperature cheppu', 'temperature enta undi', 'ushnogratha cheppu'
      ]
    },
    {
      id: 'SYSTEM_STATUS',
      description: 'Report the status of all simulated devices',
      futureEndpoint: '/status',
      triggers: [
        'system status', 'status report', 'what is the status', 'give me status', 'status update',
        'స్టేటస్ చెప్పు', 'పరిస్థితి చెప్పు', 'స్టేటస్',
        'status cheppu', 'system status cheppu'
      ]
    },
    {
      id: 'HELP',
      description: 'List available voice commands',
      futureEndpoint: null,
      triggers: [
        'help', 'what can you do', 'show commands', 'list commands', 'help me',
        'సహాయం', 'ఏమి చేయగలవు', 'నీవు ఏమి చేయగలవు',
        'help cheyyi', 'sahayam cheyyi'
      ]
    }
  ];

  return {
    STORAGE_KEYS,
    DEFAULT_ASSISTANT_NAME,
    DEFAULT_RECOGNITION_LANG,
    MAX_HISTORY,
    LANGUAGE_OPTIONS,
    COMMANDS
  };
})();
