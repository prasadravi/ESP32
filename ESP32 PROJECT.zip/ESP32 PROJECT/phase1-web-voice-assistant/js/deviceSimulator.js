/**
 * Simulated device state ONLY. No hardware, no network calls.
 * This stands in for the ESP32 + GPIO layer that gets built starting Phase 5.
 */
const VA_DeviceSimulator = (() => {
  const state = {
    light: false,
    fan: false,
    motor: false,
    temperature: 27.5 // simulated starting reading, drifts over time
  };

  const listeners = [];

  function onChange(fn) {
    listeners.push(fn);
  }

  function notify() {
    const snapshot = getState();
    listeners.forEach((fn) => fn(snapshot));
  }

  function apply(commandId) {
    switch (commandId) {
      case 'LIGHT_ON': state.light = true; break;
      case 'LIGHT_OFF': state.light = false; break;
      case 'FAN_ON': state.fan = true; break;
      case 'FAN_OFF': state.fan = false; break;
      case 'MOTOR_ON': state.motor = true; break;
      case 'MOTOR_OFF': state.motor = false; break;
      default: break;
    }
    notify();
  }

  function driftTemperature() {
    const delta = (Math.random() - 0.5) * 0.4;
    state.temperature = Math.min(34, Math.max(22, state.temperature + delta));
    notify();
  }

  function getState() {
    return { ...state, temperature: Math.round(state.temperature * 10) / 10 };
  }

  setInterval(driftTemperature, 8000);

  return { apply, getState, onChange };
})();
