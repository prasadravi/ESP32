/**
 * Thin wrapper around the Web Speech API (SpeechRecognition + SpeechSynthesis).
 *
 * Browser support note (important, do not skip when testing):
 * - Chrome / Edge (desktop + Android): full support, recommended for testing.
 * - Safari: partial SpeechRecognition support, behavior may vary.
 * - Firefox: no SpeechRecognition support as of this writing.
 * SpeechRecognition also requires a secure context (https or localhost) in
 * most browsers, or file:// in Chrome desktop — see README instructions.
 */
const VA_SpeechEngine = (() => {
  const SpeechRecognitionImpl = window.SpeechRecognition || window.webkitSpeechRecognition;
  let recognition = null;
  let listening = false;
  // `listening` only becomes true inside the async 'onstart' callback, which
  // leaves a window between calling start() and the browser actually
  // starting to listen. Without this second flag, a fast double-click on the
  // mic button (or a double-tap on mobile) can slip through the `listening`
  // check and spin up two concurrent recognition sessions — producing
  // duplicate transcripts, duplicate responses, and duplicate history entries.
  let starting = false;

  const callbacks = {
    onResult: null,
    onInterim: null,
    onStart: null,
    onEnd: null,
    onError: null,
    onSpeechError: null
  };

  function isRecognitionSupported() {
    return !!SpeechRecognitionImpl;
  }

  function isSynthesisSupported() {
    return 'speechSynthesis' in window;
  }

  function buildRecognition(lang) {
    const r = new SpeechRecognitionImpl();
    r.continuous = false;
    r.interimResults = true;
    r.lang = lang;
    r.maxAlternatives = 1;

    r.onstart = () => {
      starting = false;
      listening = true;
      if (callbacks.onStart) callbacks.onStart();
    };

    r.onend = () => {
      starting = false;
      listening = false;
      if (callbacks.onEnd) callbacks.onEnd();
    };

    r.onerror = (event) => {
      starting = false;
      listening = false;
      if (callbacks.onError) callbacks.onError(event.error);
    };

    r.onresult = (event) => {
      let interim = '';
      let final = '';
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const transcript = event.results[i][0].transcript;
        if (event.results[i].isFinal) {
          final += transcript;
        } else {
          interim += transcript;
        }
      }
      if (interim && callbacks.onInterim) callbacks.onInterim(interim);
      if (final && callbacks.onResult) callbacks.onResult(final);
    };

    return r;
  }

  function start(lang) {
    if (!isRecognitionSupported()) {
      if (callbacks.onError) callbacks.onError('not-supported');
      return;
    }
    if (listening || starting) return;
    starting = true;
    recognition = buildRecognition(lang);
    try {
      recognition.start();
    } catch (e) {
      starting = false;
      if (callbacks.onError) callbacks.onError('start-failed');
    }
  }

  function stop() {
    if (recognition && listening) recognition.stop();
  }

  function speak(text, lang, rate, voiceURI) {
    if (!isSynthesisSupported()) {
      if (callbacks.onSpeechError) callbacks.onSpeechError('not-supported');
      return;
    }
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = lang;
    utterance.rate = rate || 1;
    if (voiceURI) {
      const voice = window.speechSynthesis.getVoices().find((v) => v.voiceURI === voiceURI);
      if (voice) utterance.voice = voice;
    }
    utterance.onerror = (event) => {
      if (callbacks.onSpeechError) callbacks.onSpeechError(event.error || 'speech-error');
    };
    window.speechSynthesis.speak(utterance);
  }

  function getVoices() {
    return isSynthesisSupported() ? window.speechSynthesis.getVoices() : [];
  }

  function on(eventName, fn) {
    callbacks[eventName] = fn;
  }

  return {
    isRecognitionSupported,
    isSynthesisSupported,
    start,
    stop,
    speak,
    getVoices,
    on
  };
})();
