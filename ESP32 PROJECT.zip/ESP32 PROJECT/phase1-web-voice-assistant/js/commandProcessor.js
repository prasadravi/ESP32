/**
 * Matches a raw speech transcript against VA_CONFIG.COMMANDS.
 *
 * Why substring + token-overlap instead of exact match:
 * the Web Speech API cannot truly recognize "mixed" English+Telugu in one
 * pass (see README note in ui.js). So a mixed utterance like "light on
 * cheyyi" may come back transcribed in odd ways depending on recognition
 * language. Matching on phrase substrings, and falling back to token
 * overlap, makes command detection tolerant of that variation without
 * pretending the browser did real code-switched recognition.
 */
const VA_CommandProcessor = (() => {
  function normalize(text) {
    return text.toLowerCase().trim().replace(/[.,!?،]/g, '');
  }

  function match(transcript) {
    const norm = normalize(transcript);
    if (!norm) return null;

    let best = null;

    VA_CONFIG.COMMANDS.forEach((cmd) => {
      cmd.triggers.forEach((trigger) => {
        const t = normalize(trigger);
        if (norm.includes(t) || t.includes(norm)) {
          const score = t.length;
          if (!best || score > best.score) {
            best = { commandId: cmd.id, matchedTrigger: trigger, confidence: 'high', score };
          }
        }
      });
    });

    if (best) return best;

    const normTokens = new Set(norm.split(/\s+/).filter(Boolean));
    let fallback = null;

    VA_CONFIG.COMMANDS.forEach((cmd) => {
      cmd.triggers.forEach((trigger) => {
        const triggerTokens = normalize(trigger).split(/\s+/).filter(Boolean);
        if (triggerTokens.length === 0) return;
        const overlap = triggerTokens.filter((tok) => normTokens.has(tok)).length;
        const ratio = overlap / triggerTokens.length;
        if (ratio >= 0.6 && (!fallback || ratio > fallback.ratio)) {
          fallback = { commandId: cmd.id, matchedTrigger: trigger, ratio };
        }
      });
    });

    return fallback
      ? { commandId: fallback.commandId, matchedTrigger: fallback.matchedTrigger, confidence: 'low', score: 0 }
      : null;
  }

  return { match, normalize };
})();
