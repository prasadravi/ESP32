/**
 * Main glue: wires DOM <-> speechEngine <-> commandProcessor <-> deviceSimulator.
 * No hardware/network calls happen anywhere in this file (Phase 1 rule: simulate only).
 */
(function () {
  const dom = {
    assistantTitle: document.getElementById('assistantTitle'),
    supportDot: document.getElementById('supportDot'),
    settingsBtn: document.getElementById('settingsBtn'),
    errorBanner: document.getElementById('errorBanner'),
    micBtn: document.getElementById('micBtn'),
    micStatus: document.getElementById('micStatus'),
    stateBadge: document.getElementById('stateBadge'),
    transcriptLine: document.getElementById('transcriptLine'),
    responseLog: document.getElementById('responseLog'),
    lightState: document.getElementById('lightState'),
    fanState: document.getElementById('fanState'),
    motorState: document.getElementById('motorState'),
    tempValue: document.getElementById('tempValue'),
    systemStatusValue: document.getElementById('systemStatusValue'),
    historyList: document.getElementById('historyList'),
    historyEmpty: document.getElementById('historyEmpty'),
    clearHistoryBtn: document.getElementById('clearHistoryBtn'),
    settingsModal: document.getElementById('settingsModal'),
    assistantNameInput: document.getElementById('assistantNameInput'),
    recognitionLangSelect: document.getElementById('recognitionLangSelect'),
    voiceSelect: document.getElementById('voiceSelect'),
    rateRange: document.getElementById('rateRange'),
    rateValue: document.getElementById('rateValue'),
    closeSettingsBtn: document.getElementById('closeSettingsBtn'),
    saveSettingsBtn: document.getElementById('saveSettingsBtn'),
    resetSettingsBtn: document.getElementById('resetSettingsBtn'),
    clearHistorySettingsBtn: document.getElementById('clearHistorySettingsBtn')
  };

  const VALID_LANG_CODES = VA_CONFIG.LANGUAGE_OPTIONS.map((opt) => opt.code);

  function sanitizeAssistantName(name) {
    return (name || '').trim().slice(0, 20) || VA_CONFIG.DEFAULT_ASSISTANT_NAME;
  }

  function sanitizeRecognitionLang(lang) {
    return VALID_LANG_CODES.includes(lang) ? lang : VA_CONFIG.DEFAULT_RECOGNITION_LANG;
  }

  function sanitizeSpeechRate(rate) {
    const n = parseFloat(rate);
    return Number.isFinite(n) && n >= 0.5 && n <= 1.5 ? n : 1;
  }

  // Settings loaded from localStorage are user/browser-editable, so any of
  // these values could be missing, corrupted, or out of range (invalid
  // settings) — every field is sanitized before use rather than trusted raw.
  const settings = {
    assistantName: sanitizeAssistantName(localStorage.getItem(VA_CONFIG.STORAGE_KEYS.ASSISTANT_NAME)),
    recognitionLang: sanitizeRecognitionLang(localStorage.getItem(VA_CONFIG.STORAGE_KEYS.RECOGNITION_LANG)),
    voiceURI: localStorage.getItem(VA_CONFIG.STORAGE_KEYS.VOICE_URI) || '',
    speechRate: sanitizeSpeechRate(localStorage.getItem(VA_CONFIG.STORAGE_KEYS.SPEECH_RATE))
  };

  let history = loadHistory();

  // ---------- persistence ----------

  function loadHistory() {
    try {
      const raw = localStorage.getItem(VA_CONFIG.STORAGE_KEYS.HISTORY);
      return raw ? JSON.parse(raw) : [];
    } catch (e) {
      return [];
    }
  }

  function saveHistory() {
    localStorage.setItem(VA_CONFIG.STORAGE_KEYS.HISTORY, JSON.stringify(history));
  }

  function saveSettings() {
    localStorage.setItem(VA_CONFIG.STORAGE_KEYS.ASSISTANT_NAME, settings.assistantName);
    localStorage.setItem(VA_CONFIG.STORAGE_KEYS.RECOGNITION_LANG, settings.recognitionLang);
    localStorage.setItem(VA_CONFIG.STORAGE_KEYS.VOICE_URI, settings.voiceURI);
    localStorage.setItem(VA_CONFIG.STORAGE_KEYS.SPEECH_RATE, String(settings.speechRate));
  }

  // ---------- response text ----------

  function buildResponse(commandId, deviceState) {
    // Response language follows the recognition language: Telugu recognition
    // gets a Telugu response, everything else (English or mixed) gets English.
    const te = settings.recognitionLang === 'te-IN';
    switch (commandId) {
      case 'LIGHT_ON': return te ? 'లైట్ ఆన్ చేశాను.' : 'Light ON command received.';
      case 'LIGHT_OFF': return te ? 'లైట్ ఆఫ్ చేశాను.' : 'Light OFF command received.';
      case 'FAN_ON': return te ? 'ఫ్యాన్ ఆన్ చేశాను.' : 'Fan ON command received.';
      case 'FAN_OFF': return te ? 'ఫ్యాన్ ఆఫ్ చేశాను.' : 'Fan OFF command received.';
      case 'MOTOR_ON': return te ? 'మోటార్ ఆన్ చేశాను.' : 'Motor ON command received.';
      case 'MOTOR_OFF': return te ? 'మోటార్ ఆఫ్ చేశాను.' : 'Motor OFF command received.';
      case 'GET_TEMPERATURE':
        return te
          ? `ప్రస్తుత ఉష్ణోగ్రత ${deviceState.temperature} డిగ్రీల సెల్సియస్.`
          : `The current temperature is ${deviceState.temperature} degrees Celsius.`;
      case 'SYSTEM_STATUS':
        return te
          ? `లైట్ ${deviceState.light ? 'ఆన్' : 'ఆఫ్'}, ఫ్యాన్ ${deviceState.fan ? 'ఆన్' : 'ఆఫ్'}, ` +
            `మోటార్ ${deviceState.motor ? 'ఆన్' : 'ఆఫ్'}, ఉష్ణోగ్రత ${deviceState.temperature} డిగ్రీలు.`
          : `Light is ${deviceState.light ? 'on' : 'off'}, fan is ${deviceState.fan ? 'on' : 'off'}, ` +
            `motor is ${deviceState.motor ? 'on' : 'off'}, temperature is ${deviceState.temperature} degrees.`;
      case 'HELP':
        return te
          ? 'మీరు ఇలా చెప్పవచ్చు: లైట్ ఆన్ చెయ్యి, ఫ్యాన్ ఆఫ్, మోటార్ మొదలుపెట్టు, ఉష్ణోగ్రత ఎంత, లేదా స్టేటస్ చెప్పు.'
          : 'You can say things like, turn on the light, fan off, start the motor, what is the temperature, or system status.';
      default:
        return te
          ? 'క్షమించండి, అర్థం కాలేదు. సహాయం కోసం "help" అని చెప్పండి.'
          : 'Sorry, I did not understand that. Say help to hear what I can do.';
    }
  }

  // ---------- UI rendering ----------

  function renderDeviceState() {
    const s = VA_DeviceSimulator.getState();
    setDeviceBadge(dom.lightState, s.light);
    setDeviceBadge(dom.fanState, s.fan);
    setDeviceBadge(dom.motorState, s.motor);
    dom.tempValue.textContent = `${s.temperature}°C`;

    const onCount = [s.light, s.fan, s.motor].filter(Boolean).length;
    dom.systemStatusValue.textContent = onCount === 0
      ? 'All devices OFF'
      : `${onCount} of 3 device${onCount > 1 ? 's' : ''} ON`;
  }

  // ---------- interaction state machine (READY / LISTENING / PROCESSING / SUCCESS / ERROR) ----------

  let stateResetTimer = null;

  function setUiState(state) {
    dom.stateBadge.textContent = state;
    dom.stateBadge.className = 'state-badge state-' + state.toLowerCase();
  }

  function scheduleReturnToReady(delay) {
    if (stateResetTimer) clearTimeout(stateResetTimer);
    stateResetTimer = setTimeout(() => setUiState('READY'), delay);
  }

  function setDeviceBadge(el, isOn) {
    el.textContent = isOn ? 'ON' : 'OFF';
    el.classList.toggle('is-on', isOn);
    el.classList.toggle('is-off', !isOn);
  }

  function appendResponse(text, isError) {
    const entry = document.createElement('div');
    entry.className = 'response-entry' + (isError ? ' is-error' : '');
    entry.textContent = text;
    dom.responseLog.appendChild(entry);
    dom.responseLog.scrollTop = dom.responseLog.scrollHeight;
  }

  // Renders one full voice interaction as USER / SYSTEM / ASSISTANT rows,
  // matching the required conversation format.
  function appendConversationTurn(transcript, commandId, responseText) {
    const turn = document.createElement('div');
    turn.className = 'conversation-turn' + (commandId ? '' : ' is-unrecognized');

    const userRow = document.createElement('div');
    userRow.className = 'turn-row';
    userRow.innerHTML = `<span class="turn-label user">USER</span>` +
      `<span class="turn-text">"${escapeHtml(transcript)}"</span>`;

    const systemRow = document.createElement('div');
    systemRow.className = 'turn-row turn-system';
    systemRow.innerHTML = `<span class="turn-label system">SYSTEM</span>` +
      `<span class="turn-text turn-mono">Recognized: ${escapeHtml(transcript)}<br>Command: ${commandId || 'UNRECOGNIZED'}</span>`;

    const assistantRow = document.createElement('div');
    assistantRow.className = 'turn-row';
    assistantRow.innerHTML = `<span class="turn-label assistant">${escapeHtml(settings.assistantName)}</span>` +
      `<span class="turn-text">"${escapeHtml(responseText)}"</span>`;

    turn.appendChild(userRow);
    turn.appendChild(systemRow);
    turn.appendChild(assistantRow);
    dom.responseLog.appendChild(turn);
    dom.responseLog.scrollTop = dom.responseLog.scrollHeight;
  }

  function renderHistory() {
    dom.historyList.innerHTML = '';
    dom.historyEmpty.hidden = history.length > 0;
    history.slice().reverse().forEach((item) => {
      const li = document.createElement('li');
      li.className = 'history-item';
      const time = new Date(item.timestamp).toLocaleTimeString();
      const commandClass = 'history-command' + (item.commandId ? '' : ' is-unrecognized');
      li.innerHTML =
        `<div class="history-row">` +
          `<span class="history-time">${time}</span>` +
          `<span class="history-transcript">"${escapeHtml(item.transcript)}"</span>` +
          `<span class="${commandClass}">${item.commandId || 'UNRECOGNIZED'}</span>` +
        `</div>` +
        `<div class="history-response">${escapeHtml(item.response || '')}</div>`;
      dom.historyList.appendChild(li);
    });
  }

  function clearHistory() {
    history = [];
    saveHistory();
    renderHistory();
  }

  function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  }

  function showError(message) {
    dom.errorBanner.textContent = message;
    dom.errorBanner.hidden = false;
  }

  function hideError() {
    dom.errorBanner.hidden = true;
  }

  function setListeningUI(isListening) {
    dom.micBtn.classList.toggle('is-listening', isListening);
    dom.micStatus.textContent = isListening ? 'Listening…' : 'Tap the mic and speak a command';
  }

  // ---------- command handling ----------

  function handleTranscript(transcript) {
    setUiState('PROCESSING');

    // Empty command: the recognizer can occasionally deliver a blank/whitespace
    // final result (e.g. background noise). Treat it as an error, not a
    // silent no-op, and don't pollute history with it.
    if (!transcript || !transcript.trim()) {
      dom.transcriptLine.textContent = ' ';
      setUiState('ERROR');
      showError('No speech detected. Please try again.');
      scheduleReturnToReady(2000);
      return;
    }

    dom.transcriptLine.textContent = `"${transcript}"`;
    const result = VA_CommandProcessor.match(transcript);

    if (result) {
      VA_DeviceSimulator.apply(result.commandId);
    }

    const deviceState = VA_DeviceSimulator.getState();
    const commandId = result ? result.commandId : null;
    const responseText = buildResponse(commandId, deviceState);

    appendConversationTurn(transcript, commandId, responseText);
    VA_SpeechEngine.speak(responseText, settings.recognitionLang, settings.speechRate, settings.voiceURI);

    history.push({
      timestamp: Date.now(),
      transcript,
      commandId,
      response: responseText
    });
    if (history.length > VA_CONFIG.MAX_HISTORY) {
      history = history.slice(history.length - VA_CONFIG.MAX_HISTORY);
    }
    saveHistory();
    renderHistory();
    renderDeviceState();

    setUiState(commandId ? 'SUCCESS' : 'ERROR');
    scheduleReturnToReady(2200);
  }

  // ---------- settings modal ----------

  function populateLanguageOptions() {
    dom.recognitionLangSelect.innerHTML = '';
    VA_CONFIG.LANGUAGE_OPTIONS.forEach((opt) => {
      const option = document.createElement('option');
      option.value = opt.code;
      option.textContent = opt.label;
      dom.recognitionLangSelect.appendChild(option);
    });
    dom.recognitionLangSelect.value = settings.recognitionLang;
  }

  const MAX_VOICE_RETRIES = 10;
  let voiceRetryCount = 0;

  function populateVoiceOptions() {
    const voices = VA_SpeechEngine.getVoices();
    dom.voiceSelect.innerHTML = '';
    const defaultOption = document.createElement('option');
    defaultOption.value = '';
    defaultOption.textContent = 'Browser default';
    dom.voiceSelect.appendChild(defaultOption);
    voices.forEach((v) => {
      const option = document.createElement('option');
      option.value = v.voiceURI;
      option.textContent = `${v.name} (${v.lang})`;
      dom.voiceSelect.appendChild(option);
    });
    dom.voiceSelect.value = settings.voiceURI;

    // Safari (and some other browsers) load voices asynchronously and don't
    // reliably fire 'voiceschanged'. Poll briefly instead of relying on it.
    if (voices.length === 0 && voiceRetryCount < MAX_VOICE_RETRIES && !dom.settingsModal.hidden) {
      voiceRetryCount++;
      setTimeout(populateVoiceOptions, 300);
    }
  }

  function openSettings() {
    dom.assistantNameInput.value = settings.assistantName;
    dom.recognitionLangSelect.value = settings.recognitionLang;
    voiceRetryCount = 0;
    populateVoiceOptions();
    dom.voiceSelect.value = settings.voiceURI;
    dom.rateRange.value = settings.speechRate;
    dom.rateValue.textContent = settings.speechRate.toFixed(1);
    dom.settingsModal.hidden = false;
  }

  function closeSettings() {
    dom.settingsModal.hidden = true;
  }

  function applySettingsFromForm() {
    settings.assistantName = sanitizeAssistantName(dom.assistantNameInput.value);
    settings.recognitionLang = sanitizeRecognitionLang(dom.recognitionLangSelect.value);
    settings.voiceURI = dom.voiceSelect.value;
    settings.speechRate = sanitizeSpeechRate(dom.rateRange.value);
    saveSettings();
    dom.assistantTitle.textContent = settings.assistantName;
    closeSettings();
    appendResponse(`${settings.assistantName}: Settings saved.`);
  }

  function resetSettingsToDefaults() {
    settings.assistantName = VA_CONFIG.DEFAULT_ASSISTANT_NAME;
    settings.recognitionLang = VA_CONFIG.DEFAULT_RECOGNITION_LANG;
    settings.voiceURI = '';
    settings.speechRate = 1;
    saveSettings();
    dom.assistantTitle.textContent = settings.assistantName;

    dom.assistantNameInput.value = settings.assistantName;
    dom.recognitionLangSelect.value = settings.recognitionLang;
    dom.voiceSelect.value = settings.voiceURI;
    dom.rateRange.value = settings.speechRate;
    dom.rateValue.textContent = settings.speechRate.toFixed(1);

    appendResponse(`${settings.assistantName}: Settings reset to defaults.`);
  }

  // ---------- browser support check ----------

  let micSupported = true;

  function checkSupport() {
    const recOk = VA_SpeechEngine.isRecognitionSupported();
    const synOk = VA_SpeechEngine.isSynthesisSupported();
    micSupported = recOk;
    if (recOk && synOk) {
      dom.supportDot.classList.add('is-ok');
      dom.supportDot.title = 'Speech recognition and synthesis supported';
    } else {
      dom.supportDot.classList.add('is-warn');
      dom.supportDot.title = 'Limited browser support detected';
      showError(
        (recOk ? '' : 'Speech recognition is not supported in this browser. ') +
        (synOk ? '' : 'Speech synthesis is not supported in this browser. ') +
        'Please use desktop Chrome or Edge for full functionality.'
      );
      dom.micBtn.disabled = !recOk;
    }
  }

  // ---------- events ----------

  dom.micBtn.addEventListener('click', () => {
    hideError();
    if (stateResetTimer) clearTimeout(stateResetTimer);
    dom.transcriptLine.textContent = ' ';
    // Belt-and-braces alongside speechEngine's own start/starting guard:
    // disabling the button means a fast double-click can't even dispatch a
    // second 'click' event while a recognition session is spinning up.
    dom.micBtn.disabled = true;
    VA_SpeechEngine.start(settings.recognitionLang);
  });

  dom.settingsBtn.addEventListener('click', openSettings);
  dom.closeSettingsBtn.addEventListener('click', closeSettings);
  dom.saveSettingsBtn.addEventListener('click', applySettingsFromForm);
  dom.resetSettingsBtn.addEventListener('click', resetSettingsToDefaults);
  dom.clearHistorySettingsBtn.addEventListener('click', clearHistory);
  dom.rateRange.addEventListener('input', () => {
    dom.rateValue.textContent = parseFloat(dom.rateRange.value).toFixed(1);
  });

  dom.clearHistoryBtn.addEventListener('click', clearHistory);

  // Professional modal UX: click outside the panel or press Escape to close.
  dom.settingsModal.addEventListener('click', (e) => {
    if (e.target === dom.settingsModal) closeSettings();
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && !dom.settingsModal.hidden) closeSettings();
  });

  if ('speechSynthesis' in window) {
    window.speechSynthesis.onvoiceschanged = () => {
      if (!dom.settingsModal.hidden) populateVoiceOptions();
    };
  }

  VA_SpeechEngine.on('onStart', () => {
    setListeningUI(true);
    setUiState('LISTENING');
  });
  VA_SpeechEngine.on('onEnd', () => {
    setListeningUI(false);
    if (micSupported) dom.micBtn.disabled = false;
    // If recognition ended with no result and no error (e.g. user tapped
    // stop, or the browser just gave up silently), fall back to READY
    // instead of getting stuck showing "LISTENING".
    if (dom.stateBadge.textContent === 'LISTENING') {
      setUiState('READY');
    }
  });
  VA_SpeechEngine.on('onInterim', (text) => {
    dom.transcriptLine.textContent = `"${text}"`;
  });
  VA_SpeechEngine.on('onResult', (transcript) => {
    handleTranscript(transcript);
  });
  VA_SpeechEngine.on('onError', (errorCode) => {
    setListeningUI(false);
    if (micSupported) dom.micBtn.disabled = false;
    setUiState('ERROR');
    const messages = {
      'not-allowed': 'Microphone permission was denied. Please allow microphone access and try again.',
      'no-speech': 'No speech was detected. Please try again.',
      'audio-capture': 'No microphone was found. Please connect a microphone and try again.',
      'not-supported': 'Speech recognition is not supported in this browser.',
      'network': 'A network error occurred during speech recognition.'
    };
    showError(messages[errorCode] || `Speech recognition error: ${errorCode}`);
    scheduleReturnToReady(2500);
  });
  VA_SpeechEngine.on('onSpeechError', (errorCode) => {
    showError(`Voice playback failed (${errorCode}), but the response is shown above.`);
  });

  VA_DeviceSimulator.onChange(renderDeviceState);

  // ---------- init ----------

  dom.assistantTitle.textContent = settings.assistantName;
  populateLanguageOptions();
  checkSupport();
  renderDeviceState();
  renderHistory();
  appendResponse(`${settings.assistantName}: Ready. Tap the mic and try a command, or say "help".`);
})();
